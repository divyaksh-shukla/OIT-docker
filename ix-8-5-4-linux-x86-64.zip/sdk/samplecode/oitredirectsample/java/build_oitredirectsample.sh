
javac -cp ../../../../redist/oilink.jar -d ../../../demo OITRedirectSample.java

