
javac -cp ../../../../redist/oilink.jar -d ../../../demo OITSample.java

