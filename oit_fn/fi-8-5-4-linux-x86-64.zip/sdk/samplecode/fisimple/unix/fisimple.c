/*
 |   Extended FI Sample Application
 |
 |   Copyright (c) 2001, 2016, Oracle and/or its affiliates. All rights reserved.
 |
 |   You have a royalty-free right to use, modify, reproduce and
 |   distribute the Sample Applications (and/or any modified version)
 |   in any way you find useful, provided that you agree that Oracle
 |   has no warranty obligations or liability for any Sample Application
 |   files which are modified.
 */

#ifndef UNIX
#define UNIX
#endif

#define MAXCHARS 4096

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#if defined(_DARWIN_SOURCE)
/* For Mac OS X look for headers in the OIVT framework. */
#include <OIVT/sccfi.h>
#include <OIVT/sccerr.h>
#else
#include <sccfi.h>
#include <sccerr.h>
#endif

/*
   Oracle does version tracking of the Outside In sample applications.
   OIT_VERSTRING is defined by internal build scripts so you can delete
   the following line at your leisure as it performs no real function.
*/
#ifdef OIT_VERSTRING
char oitsamplever[32] = OIT_VERSTRING;
#endif

#ifndef FALSE
#define FALSE 0
#endif
#ifndef TRUE
#define TRUE !FALSE
#endif

void PrintUsageMessage();

int main(int argc, char *argv[])
{
    SCCERR  err;
    VTDWORD dwFlags = FIFLAG_NORMAL;
    VTBOOL  bDisplayFileName = TRUE;
    VTWORD  wType;
    VTBYTE  pTypeName[ MAXCHARS ];
    VTWORD  wFileArg = 1;
    int     exitCode;
    int     i;
  
#if defined(_DARWIN_SOURCE)
    /* Create an autorelease pool for OS X. */
    NSAutoreleasePool   *pool = [ [ NSAutoreleasePool alloc ] init ];
#endif

    if (argc < 2)
    {
        PrintUsageMessage();
        exit(-1);
    }

    for (i = 1; i < argc - 1; i++)
    {
        if (strcmp(argv[i], "-n") == 0)
            dwFlags = FIFLAG_NORMAL;
        else if (strcmp(argv[i], "-e") == 0)
            dwFlags = FIFLAG_EXTENDEDFI;
        else if (strcmp(argv[i], "-q") == 0)
            bDisplayFileName = FALSE;
        else 
        {
            PrintUsageMessage();
            exit(-1);
        }
    }

    wFileArg = i;
   
    /*
     | Now call FI to do the ID and to get the string, and then dump the string to stdout
     | or indicate the error that occurred
     */ 
    err = FIInit();
	if (err != SCCERR_OK)
	{
		printf( "An error occurred during the FI initialization. Error Code:   %x\n",  (unsigned int)err );
        exitCode = -1;
        goto finish;
	}

    err = FIIdFileEx( IOTYPE_UNIXPATH, argv[wFileArg], dwFlags, &wType, (char *)pTypeName, MAXCHARS );

    if( err == SCCERR_OK )
    {
        if (bDisplayFileName)
            printf( "File : %s  - ID : %d (0x%04X) - String ID name:  %s\n", argv[wFileArg], wType, wType, (char *)pTypeName );
        else
            printf("ID : %d (0x%04X) - String ID name:  %s\n", wType, wType, (char *)pTypeName);
        exitCode = 0;
        goto finish; 
    }
    else
    {
        printf( "An error occurred during the FI process. File %s - Error Code:   %x\n", argv[wFileArg], (unsigned int)err );
        exitCode = -1;
        goto finish;
    }
    
finish:

#if defined(_DARWIN_SOURCE)
    /* Release the autorelease pool. */
    [ pool release ];
#endif

    FIDeInit();

    return exitCode;
}

void PrintUsageMessage()
{
       printf( "USAGE:  fisimple [-n | -e] [-q] filename\n" );
       printf( "           -n indicates normal FI processing (default)\n" );
       printf( "           -e indicates extended FI processing\n" );
       printf( "           -q suppress echo of filename\n\n" );
}
